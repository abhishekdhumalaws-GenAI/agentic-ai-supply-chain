import json
import re
from model_service import invoke_model

def lambda_handler(event, context):

    user_input = event.get("input", "")

    prompt = f"""
    You are a planning agent.

    User request:
    {user_input}

    Available tools:
    - check_inventory
    - estimate_demand

    Return ONLY JSON:
    {{
      "actions": ["check_inventory", "estimate_demand"],
      "product_id": "<extract>"
    }}
    """

    response = invoke_model("nova", prompt)

    try:
        json_str = re.search(r'\{.*\}', response, re.DOTALL).group()
        result = json.loads(json_str)
    except:
        result = {"actions": [], "product_id": ""}

    return {
        "statusCode": 200,
        "body": json.dumps({
            "input": user_input,
            "plan": result
        })
    }
