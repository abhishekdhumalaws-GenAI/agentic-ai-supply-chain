import json
import boto3
from datetime import datetime
from model_service import invoke_model

# DynamoDB
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('agent-memory')

def get_memory(product_id):
    try:
        response = table.get_item(Key={"product_id": product_id})
        return response.get("Item", {})
    except:
        return {}

def save_memory(product_id, inventory, demand):
    table.put_item(
        Item={
            "product_id": product_id,
            "inventory": inventory,
            "demand": demand,
            "timestamp": str(datetime.utcnow())
        }
    )

def lambda_handler(event, context):

    body = json.loads(event["body"])

    user_input = body["input"]
    plan = body["plan"]
    execution = body["execution"]

    product_id = plan.get("product_id", "p1")

    memory = get_memory(product_id)

    save_memory(
        product_id,
        execution.get("inventory", {}),
        execution.get("demand", {})
    )

    prompt = f"""
    User request: {user_input}

    Execution results:
    {execution}

    Previous memory:
    {memory}

    Provide final optimized recommendation.
    """

    final = invoke_model("nova", prompt)

    return {
        "statusCode": 200,
        "body": json.dumps({
            "result": final
        })
    }
