import json
from tools import check_inventory, estimate_demand

def lambda_handler(event, context):

    body = json.loads(event["body"])

    product_id = body["plan"].get("product_id", "p1")
    actions = body["plan"].get("actions", [])

    results = {}

    if "check_inventory" in actions:
        results["inventory"] = check_inventory(product_id)

    if "estimate_demand" in actions:
        results["demand"] = estimate_demand(product_id)

    return {
        "statusCode": 200,
        "body": json.dumps({
            "input": body["input"],
            "plan": body["plan"],
            "execution": results
        })
    }
